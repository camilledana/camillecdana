# Name: Camille Dana
# ID: 003277157
# Temperature Convert Celsius to Fahrenheit
# To Convert Fahrenheit to Celsius:
# def Fahrenheit = (Celsius * 9 / 5) + 32
# To Convert Celsius to Fahrenheit:
# def Celsius[C1,C2] = (Fahrenheit-32) * 5 / 9

Fahrenheit = 30 * 9 / 5 + 32
C1 = (50-32) * 5 / 9
C2 = (71-32) * 5 / 9

temperature_1_celsius = 30
temperature_2_fahrenheit = 50
temperature_3_fahrenheit = 71

print(Fahrenheit)

print(C1)

print(round(C2, 1))


