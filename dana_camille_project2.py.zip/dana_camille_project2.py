# Name: Camille Dana
# ID: 003277157

# Display the best customer of the day.
#
def nameOfBestCustomer(sales, customers):
    mymax = max(sales)
    ind = sales.index(mymax)
    return customers[ind], sales[ind]


def nameOfBestCustomer(sales, customers):
    mymax = max(sales)
    ind = sales.index(mymax)
    return customers[ind], sales[ind]

def intake():
    name = []
    price = []
    p = float(input("Please Enter the purchase amount: "))
    while p != -1:
        price.append(p)
        n = input("Please Enter name of customer: ")
        name.append(n)
        p = float(input("Please Enter the purchase amount: "))
    return price, name


if __name__ == "__main__":
    price, name = intake()
    cus, sal = nameOfBestCustomer(price, name)
    print("The best customer of the day is", cus, "with largest sale of", sal)